def main():
    cough(3)

def cough(n):
    for i in range(n):
        print("cough")

main()