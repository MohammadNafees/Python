from cs50 import get_string

s = get_string("S: ")
t = get_string("T: ")

if s == t:
    print("Same")
else:
    print("Different")