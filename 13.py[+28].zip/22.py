scores = [72, 73, 33]

print(f"Average: {sum(scores) / len(scores)}")